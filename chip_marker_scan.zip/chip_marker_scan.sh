#!/bin/bash

# 定义版本信息
VERSION="1.0.0"

set -u

# ============================================================
# 用途：
#   每次执行时扫描指定目录通配符下的 Upload 目录，识别形如：
#     ChipID_LaneID_success.txt
#   的标记文件，并在同目录下自动生成：
#     ChipID_LaneID.txt
#
# 示例：
#   V30003222_L04_success.txt  ->  V30003222_L04.txt
#   V30003222_L04_Success.txt  ->  V30003222_L04.txt
#   V30003222_L04_done.txt     ->  V30003222_L04.txt
#
# 说明：
#   1. 关键字支持多个，如 success / done / complete
#   2. 关键字匹配大小写不敏感
#   3. 目标文件已存在时自动跳过，不覆盖
#   4. 建议配合 cron 每 5 分钟执行一次
#   5. 兼容 CentOS / Ubuntu（要求 /bin/bash）
# ============================================================

# ======================== 可配置区域开始 ========================

# 需要扫描的目录通配符，可配置多个。
# 例如：
#   "/mnt/Data/*/Info/Upload"
#   "/data/project/*/Upload"
SCAN_GLOBS=(
  "/mnt/Data/*/Info/Upload"
)

# 成功标记关键字，支持多个，大小写不敏感。
# 例如：
#   xxx_success.txt
#   xxx_Success.txt
#   xxx_done.txt
MARKER_KEYWORDS=(
  "success"
  #"done"
  #"complete"
)

# 日志文件路径。
LOG_FILE="/var/log/chip_marker_scan.log"

# 锁目录路径，用于避免任务重叠执行。
LOCK_PATH="/tmp/chip_marker_scan.lock"

# 是否仅演练不真正创建文件：1=是，0=否。
DRY_RUN=0

# ======================== 可配置区域结束 ========================

if [[ ${#SCAN_GLOBS[@]} -eq 0 ]]; then
  printf 'SCAN_GLOBS is empty\n' >&2
  exit 1
fi

if [[ ${#MARKER_KEYWORDS[@]} -eq 0 ]]; then
  printf 'MARKER_KEYWORDS is empty\n' >&2
  exit 1
fi

patterns_processed=0
directories_resolved=0
files_inspected=0
marker_matches=0
created_count=0
skipped_existing=0
error_count=0

declare -A SEEN_DIRS=()

timestamp() {
  date '+%Y-%m-%d %H:%M:%S'
}

log() {
  local level="$1"
  shift
  local line="[$(timestamp)] [$level] $*"

  if [[ -n "$LOG_FILE" ]]; then
    mkdir -p "$(dirname "$LOG_FILE")" 2>/dev/null || true
    printf '%s\n' "$line" >> "$LOG_FILE" 2>/dev/null || printf '%s\n' "$line" >&2
  else
    printf '%s\n' "$line" >&2
  fi
}

release_lock() {
  [[ -d "$LOCK_PATH" ]] && rmdir "$LOCK_PATH" 2>/dev/null || true
}

acquire_lock() {
  if mkdir "$LOCK_PATH" 2>/dev/null; then
    trap release_lock EXIT INT TERM
  else
    log "WARN" "Skip run because lock exists: $LOCK_PATH"
    exit 0
  fi
}

process_file() {
  local file_path="$1"
  local dir_path="$2"
  local file_name lower_name keyword lower_keyword suffix_len target_base target_path

  [[ -f "$file_path" ]] || return 0

  file_name="$(basename "$file_path")"
  lower_name="${file_name,,}"

  [[ "$lower_name" == *.txt ]] || return 0

  files_inspected=$((files_inspected + 1))

  for keyword in "${MARKER_KEYWORDS[@]}"; do
    lower_keyword="${keyword,,}"

    if [[ "$lower_name" == *"_${lower_keyword}.txt" ]]; then
      marker_matches=$((marker_matches + 1))
      suffix_len=$(( ${#keyword} + 5 ))
      target_base="${file_name:0:${#file_name}-suffix_len}"

      if [[ -z "$target_base" ]]; then
        error_count=$((error_count + 1))
        log "ERROR" "Invalid marker filename: $file_path"
        return 0
      fi

      target_path="$dir_path/$target_base.txt"

      if [[ -e "$target_path" ]]; then
        skipped_existing=$((skipped_existing + 1))
        #log "INFO" "Target already exists, skip: $target_path"
        return 0
      fi

      if [[ "$DRY_RUN" == "1" ]]; then
        log "INFO" "DRY_RUN create: $target_path (from $file_name)"
        return 0
      fi

      if : > "$target_path" 2>/dev/null; then
        created_count=$((created_count + 1))
        log "INFO" "Created target: $target_path (from $file_name)"
      else
        error_count=$((error_count + 1))
        log "ERROR" "Failed to create target: $target_path"
      fi

      return 0
    fi
  done
}

process_directory() {
  local dir_path="$1"
  local item

  if [[ ! -d "$dir_path" ]]; then
    error_count=$((error_count + 1))
    log "ERROR" "Directory not found: $dir_path"
    return 0
  fi

  if [[ ! -r "$dir_path" || ! -w "$dir_path" ]]; then
    error_count=$((error_count + 1))
    log "ERROR" "Directory is not readable/writable: $dir_path"
    return 0
  fi

  for item in "$dir_path"/*; do
    [[ -e "$item" ]] || continue
    process_file "$item" "$dir_path"
  done
}

main() {
  local pattern resolved_dir
  local -a matched_dirs=()

  acquire_lock
  shopt -s nullglob

  for pattern in "${SCAN_GLOBS[@]}"; do
    patterns_processed=$((patterns_processed + 1))
    mapfile -t matched_dirs < <(compgen -G "$pattern")

    if [[ ${#matched_dirs[@]} -eq 0 ]]; then
      log "WARN" "No directories matched pattern: $pattern"
      continue
    fi

    for resolved_dir in "${matched_dirs[@]}"; do
      [[ -d "$resolved_dir" ]] || continue

      if [[ -n "${SEEN_DIRS[$resolved_dir]:-}" ]]; then
        continue
      fi

      SEEN_DIRS[$resolved_dir]=1
      directories_resolved=$((directories_resolved + 1))
      process_directory "$resolved_dir"
    done
  done

  shopt -u nullglob

  log "INFO" "Summary patterns=$patterns_processed directories=$directories_resolved files=$files_inspected matches=$marker_matches created=$created_count skipped_existing=$skipped_existing errors=$error_count dry_run=$DRY_RUN"
}

main
