# chip_marker_scan 部署文档

## 环境要求

- OS：CentOS 7+ 或 Ubuntu 14.04+
- Shell：`/bin/bash`（Bash 4.0+）
- 权限：cron 运行账号对扫描目录有读写权限

---

## 文件说明

| 文件 | 说明 |
|------|------|
| `chip_marker_scan.sh` | 主脚本，含内置配置 |
| `chip_marker.cron` | cron 示例文件（方式一使用） |

---

## 部署步骤

### 1. 上传脚本

```bash
cp chip_marker_scan.sh /usr/local/bin/chip_marker_scan.sh
chmod +x /usr/local/bin/chip_marker_scan.sh
```

### 2. 修改配置

编辑脚本顶部"可配置区域"：

```bash
vi /usr/local/bin/chip_marker_scan.sh
```

关键配置项：

```bash
# 扫描目录通配符（可配置多个）
SCAN_GLOBS=(
  "/mnt/Data/*/Info/Upload"
)

# 标记关键字（大小写不敏感）
MARKER_KEYWORDS=(
  "success"
  #"done"
  #"complete"
)

# 日志路径
LOG_FILE="/var/log/chip_marker_scan.log"

# 锁文件路径
LOCK_PATH="/tmp/chip_marker_scan.lock"

# 演练模式：1=不创建文件只打印日志，0=正常执行
DRY_RUN=0
```

### 3. 手动测试

```bash
# 演练模式验证（不创建文件）
DRY_RUN=1 /bin/bash /usr/local/bin/chip_marker_scan.sh

# 正式执行
/bin/bash /usr/local/bin/chip_marker_scan.sh
```

查看日志：

```bash
tail -f /var/log/chip_marker_scan.log
```

### 4. 安装 cron

两种方式任选其一：

#### 方式一：/etc/cron.d（推荐，系统级）

```bash
cp chip_marker.cron /etc/cron.d/chip_marker
chmod 644 /etc/cron.d/chip_marker
```

`/etc/cron.d/chip_marker` 内容：

```
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

*/5 * * * * root /bin/bash /usr/local/bin/chip_marker_scan.sh >> /var/log/chip_marker_scan.cron.log 2>&1
```

> `/etc/cron.d/` 下的文件由 cron 守护进程自动检测，**无需重启服务**。

#### 方式二：crontab（用户级）

```bash
crontab -e
```

添加以下行：

```
*/5 * * * * /bin/bash /usr/local/bin/chip_marker_scan.sh >> /var/log/chip_marker_scan.cron.log 2>&1
```

> `crontab -e` 保存后立即生效，**无需重启服务**。

---

验证 cron 服务运行中：

```bash
# CentOS
systemctl status crond

# Ubuntu
systemctl status cron
```

---

## 验证

### 功能验证

```bash
# 创建测试目录和标记文件
mkdir -p /mnt/Data/TEST/Info/Upload
touch /mnt/Data/TEST/Info/Upload/V30003222_L04_success.txt
touch /mnt/Data/TEST/Info/Upload/V30003222_L05_Success.txt

# 执行脚本
/bin/bash /usr/local/bin/chip_marker_scan.sh

# 确认生成目标文件
ls /mnt/Data/TEST/Info/Upload/
# 预期：V30003222_L04.txt  V30003222_L05.txt
```

### 幂等性验证

```bash
# 再次执行，确认不重复创建
/bin/bash /usr/local/bin/chip_marker_scan.sh

# 查看日志，skipped_existing 应 > 0，created 应为 0
tail -1 /var/log/chip_marker_scan.log
```

---

## 日志说明

日志格式：

```
[2026-04-16 10:00:01] [INFO] Created target: /mnt/Data/A/Info/Upload/V30003222_L04.txt (from V30003222_L04_success.txt)
[2026-04-16 10:00:01] [INFO] Summary patterns=1 directories=3 files=10 matches=2 created=2 skipped_existing=8 errors=0 dry_run=0
```

每日日志量估算：

| 场景 | 日志行/天 |
|------|-----------|
| 无新文件 | ~288 行（仅 Summary） |
| 每天新增 100 文件 | ~388 行 |

---

## 日志轮转（可选）

```bash
cat > /etc/logrotate.d/chip_marker << 'EOF'
/var/log/chip_marker_scan.log {
    daily
    rotate 30
    compress
    missingok
    notifempty
}
EOF
```

---

## 常见问题

| 现象 | 排查方向 |
|------|----------|
| 日志无输出 | 检查 `/var/log/chip_marker_scan.log` 写权限 |
| 目标文件未生成 | 检查扫描目录读写权限；确认标记文件名格式正确 |
| cron 不执行 | 检查 `/etc/cron.d/chip_marker` 权限为 644；检查 crond/cron 服务状态 |
| 锁未释放 | 手动删除 `rm -rf /tmp/chip_marker_scan.lock` |
